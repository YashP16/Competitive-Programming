                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1514145
Drawing Machine by cyul is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

### Updates
**20160910** Alternative Z stage that uses metal LM6UU linear bearings. The bearings should snap in their receptacles. Tinkercad model is [here](https://tinkercad.com/things/kE7g5WlPCMW).

**20160614** New Z stage, now integrated into the Y end. Unimaginatively called "v2". Same gear, same pen holder, a bit stronger, a bit better (one less part, less screws).

Print these:
- drawing_machine_y_end2_v2.obj, and
- drawing_machine_z_stage_face_v2.obj 

To replace these:
- drawing_machine_y_end2.obj, 
- drawing_machine_z_stage.obj, and
- drawing_machine_z_stage_face.obj.

**20160505** updated some searches in the grocery list

### Summary
My take on [Misan's drawing machine](http://www.thingiverse.com/thing:1444216). I made one with a [grbl](https://github.com/grbl/grbl) controller and a [CNC shield](http://blog.protoneer.co.nz/arduino-cnc-shield/) and adapted Misan's parts to be 3D printed.

Please read Misan's instructions as well.

The Z stage does not use a servo, as in Misan's machine, but rather one of those cheap 28BYJ stepper motors you can find for 1.50$ on [eBay](http://www.ebay.com/sch/i.html?_nkw=28BYJ). 

NOTE: The photos are of the current prototype, some of the modifications to the various bits and pieces have not yet been tested.

This thing was made with Tinkercad. Edit it [here](https://www.tinkercad.com/things/d7ghroB3kTO).

# Print Settings

Printer: Wanhao i3 Duplicator
Resolution: 0.2 mm
Infill: 15% minimum

Notes: 
The Y end stops take a lot of tension from the belt. Making them as strong as possible to prevent flexing is not a bad idea.

# How-to

## Model Files

The first model file shows all the pieces that are then isolated for your convenience into separate files. For some reason, when you upload OBJ to Thingiverse, objects are rotated 90 degrees (clockwise) around the X axis. Rotate -90 degrees in your slicer before printing. Of course, the two model files that are in the STL format (they come directly from Misan's model) are not rotated. Go figure...

## Grocery list

Definitely **not** [450$ worth of parts](http://shop.evilmadscientist.com/productsmenu/846)...

Below are some searches on eBay that you could use for your own machine. I am not affiliated with any of the vendors that those searches may yield. Please proceed with caution on eBay.

#####You will need:

1 x Arduino (any [cheap clone](http://www.ebay.com/sch/i.html?_nkw=Arduino+UNO+R3+ATmega328P+CH340) will do) with USB cable

1 x [CNC shield](http://www.ebay.com/sch/i.html?_nkw=Arduino+CNC+Shield+GRBL)

3 x [Stepper drivers](http://www.ebay.com/sch/i.html?_nkw=Stepper+driver+A4988)

1 x 12V power supply (the one I have is a quite beefy 12.5A, salvaged from another project)

4 x [8 mm diameter rods](http://www.ebay.com/sch/i.html?_nkw=8mm+optical+rod), any length you want (by pairs though). I used 2 x 400mm for X and 2 x 300 mm for Y (recycled from printers and scanners.) With these lengths, and the new Z stage, I get about 312(X) x 212(Y) x 23(Z) mm of workspace.

2 x X lengths of 10 mm (or 3/8") threaded rod, with associated bolts, washers and nuts

8 x [LM8UU linear bearings](http://www.ebay.com/sch/i.html?_nkw=LM8UU+linear+bearing)

2 x [NEMA 17 steppers](http://www.ebay.com/sch/i.html?_nkw=nema17+stepper)

[Cables and connectors](http://www.ebay.com/sch/i.html?_nkw=Ramps+Wiring++Kit)

5 x [smooth idler pulleys](http://www.ebay.com/sch/i.html?_nkw=10mm+idler+pulley+smooth+gt2) (16 teeth or 10 mm, 3 mm bore)

2 x [pulleys](http://www.ebay.com/sch/i.html?_nkw=GT2+timing+pulley+5mm+bore+16+teeth) (16 teeth, 5 mm bore)

[GT2 belt](http://www.ebay.com/sch/i.html?_nkw=GT2+belt): to know how much you need, add your X to your Y, multiply by two and add two inches for luck

An assortment of M3 bolts in various length and their nuts 

#####For the Z stage:

1 x [28BYJ](http://www.ebay.com/sch/i.html?_nkw=28BYJ) stepper motor

1 x M5 bolt to secure the pen to the Z carriage

2 x 60+ mm of [6 mm diameter rod](http://www.ebay.com/sch/i.html?_nkw=6mm+optical+rod) (I got mine from an old scanner)

The 28BYJ can be 5V or 12V. It does not matter, since it does not run continuously.
Contrarily to what some people seem to think, you don't have to open the stepper to cut a trace on its PCB, just ignore the red wire and use: orange, pink, blue, yellow, in that order.

The last model file and photograph show (hopefully) how it all fits together.

## grbl

You will need to re-[compile grbl](https://github.com/grbl/grbl/wiki/Compiling-Grbl) to activate CoreXY control.

Before you compile, change config.h as such:

`#define HOMING_CYCLE_0 (1<<X_AXIS)`
`#define HOMING_CYCLE_1 (1<<Y_AXIS)`

`// and this below goes uncommented`
`#define COREXY`

## Control Software

For control, I am using [bCNC](https://github.com/cheton/cnc). Neat package.
I use Inkscape with [Gcodetools extension](http://www.cnc-club.ru/gcodetools) to generate gcode. YMMV.

## grbl Settings (YMMV)

$4=0 (step enable invert, bool)
$5=0 (limit pins invert, bool)
$6=0 (probe pin invert, bool)
$10=3 (status report mask:00000011)
$11=0.010 (junction deviation, mm)
$12=0.002 (arc tolerance, mm)
$13=0 (report inches, bool)
$20=0 (soft limits, bool)
$21=1 (hard limits, bool)
$22=0 (homing cycle, bool)
$23=0 (homing dir invert mask:00000000)
$24=25.000 (homing feed, mm/min)
$25=500.000 (homing seek, mm/min)
$26=250 (homing debounce, msec)
$27=1.000 (homing pull-off, mm)
$100=96.000 (x, step/mm)
$101=96.000 (y, step/mm)
$102=814.000 (z, step/mm)
$110=20000.000 (x max rate, mm/min)
$111=20000.000 (y max rate, mm/min)
$112=2200.000 (z max rate, mm/min)
$120=200.000 (x accel, mm/sec^2)
$121=50.000 (y accel, mm/sec^2)
$122=200.000 (z accel, mm/sec^2)
$130=212.000 (x max travel, mm)
$131=312.000 (y max travel, mm)
$132=23.000 (z max travel, mm)